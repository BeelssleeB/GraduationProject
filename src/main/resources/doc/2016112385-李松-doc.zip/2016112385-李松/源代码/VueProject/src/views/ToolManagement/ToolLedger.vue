<template>
    <div>
        工具台账
    </div>
</template>

<script>
    export default {
        name: "ToolLedger"
    }
</script>

<style scoped>

</style>
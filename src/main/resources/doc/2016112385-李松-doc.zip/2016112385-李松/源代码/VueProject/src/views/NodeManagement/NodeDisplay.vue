<template>
    <div>
        节点展示
    </div>
</template>

<script>
    export default {
        name: "NodeDisplay"
    }
</script>

<style scoped>

</style>
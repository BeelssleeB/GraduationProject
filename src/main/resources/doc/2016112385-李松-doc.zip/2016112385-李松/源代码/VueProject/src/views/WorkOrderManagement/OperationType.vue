<template>
    <div>
        作业类型
    </div>
</template>

<script>
    export default {
        name: "OperationType"
    }
</script>

<style scoped>

</style>
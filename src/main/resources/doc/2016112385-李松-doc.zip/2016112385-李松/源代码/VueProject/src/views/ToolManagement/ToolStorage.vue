<template>
    <div>
        工具入库
    </div>
</template>

<script>
    export default {
        name: "ToolStorage"
    }
</script>

<style scoped>

</style>
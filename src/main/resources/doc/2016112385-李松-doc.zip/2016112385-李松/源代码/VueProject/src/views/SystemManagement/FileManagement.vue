<template>
    <div>
        文件管理
    </div>
</template>

<script>
    export default {
        name: "FileManagement"
    }
</script>

<style scoped>

</style>
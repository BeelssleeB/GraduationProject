<template>
  <div>
      <h1>404 Error! Page Not Found!</h1>
  </div>
</template>

<script>
export default {
  name: "404",
  data() {
    return {};
  },
  methods: {
  }
};
</script>


<style scoped>
h1{
    font-size: 30px;
    color: black;
    margin: 200px auto;
}
</style>

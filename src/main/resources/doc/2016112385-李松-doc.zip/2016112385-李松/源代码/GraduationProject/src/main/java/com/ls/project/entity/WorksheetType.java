package com.ls.project.entity;

public class WorksheetType {
    private Integer id;
    private String worksheetType;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getWorksheetType() {
        return worksheetType;
    }

    public void setWorksheetType(String worksheetType) {
        this.worksheetType = worksheetType;
    }
}

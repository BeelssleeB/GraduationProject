package com.ls.project.service;

import com.ls.project.entity.Log;

public interface LogService {

    void save(Log log);
}
